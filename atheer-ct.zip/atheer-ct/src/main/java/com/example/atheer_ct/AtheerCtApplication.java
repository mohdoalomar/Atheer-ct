package com.example.atheer_ct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtheerCtApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtheerCtApplication.class, args);
	}

}
