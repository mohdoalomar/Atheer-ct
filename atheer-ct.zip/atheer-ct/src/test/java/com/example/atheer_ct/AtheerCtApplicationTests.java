package com.example.atheer_ct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtheerCtApplicationTests {

	@Test
	void contextLoads() {
	}

}
